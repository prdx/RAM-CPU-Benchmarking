typedef struct __address_info_t {
  double time;
  struct __address_info_t *next;
} address_info_t;
